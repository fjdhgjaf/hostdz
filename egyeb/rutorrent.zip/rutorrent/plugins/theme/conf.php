<?php

$defaultTheme = ""; // May be "", "Oblivion", "Dark", "Blue" or "Acid"
