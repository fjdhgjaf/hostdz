﻿/*
 * PLUGIN THEME
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.themeStandard	= "표준";
 theUILang.theme		= "테마";

thePlugins.get("theme").langLoaded();
