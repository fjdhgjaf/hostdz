<?php
	// configuration parameters

	$maxConcurentTasks 	= 3;	
	$showTabAlways		= 1;	// if 1 then show tab 'Tasks' on the start always. If 0 - then only if background tasks exists