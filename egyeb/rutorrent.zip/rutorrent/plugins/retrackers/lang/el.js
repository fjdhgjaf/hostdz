﻿/*
 * PLUGIN RETRACKERS
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Προσθήκη ανακοινώσεων";
 theUILang.retrackersDel	= "Αφαίρεση ανακοινώσεων";
 theUILang.dontAddToPrivate	= "Να μην πειραχτούν τα ιδιωτικά torrent";
 theUILang.addToBegin		= "Προσθήκη ανακοινώσεων στην αρχή της λίστας των tracker";

thePlugins.get("retrackers").langLoaded();