﻿/*
 * PLUGIN RETRACKERS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.retrackers		= "Ретрекеры";
 theUILang.retrackersAdd	= "Добавить анонсы";
 theUILang.retrackersDel	= "Удалить анонсы";
 theUILang.dontAddToPrivate	= "Не модифицировать частные раздачи";
 theUILang.addToBegin		= "Добавлять анонсы в начало списка";

thePlugins.get("retrackers").langLoaded();