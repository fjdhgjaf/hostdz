﻿/*
 * PLUGIN SOURCE
 *
 * Hungarian language file.
 *
 * Author: Olivér (titititatatatititi@gmail.com)
 */

 theUILang.getSource		= ".torrent letöltése";
 theUILang.cantFindTorrent	= "A letöltés torrent fájlja nem található.";

thePlugins.get("source").langLoaded();