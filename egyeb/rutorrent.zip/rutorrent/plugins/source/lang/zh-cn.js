﻿/*
 * PLUGIN SOURCE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.getSource		= "获取 .torrent";
 theUILang.cantFindTorrent	= "Source torrent file for this download not found.";

thePlugins.get("source").langLoaded();