﻿/*
 * PLUGIN TRAFFIC
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.traf 		= "Трафік";
 theUILang.perDay		= "За добу";
 theUILang.perMonth		= "За місяць";
 theUILang.perYear		= "За рік";
 theUILang.allTrackers		= "Усі трекери";
 theUILang.ClearButton		= "Очистити";
 theUILang.ClearQuest		= "Справді очистити статистику для вибраних трекерів?";
 theUILang.selectedTorrent	= "Вибрание торенти";
 theUILang.ratioDay		= "Коефіцієнт/день";
 theUILang.ratioWeek		= "Коефіцієнт/тиждень";
 theUILang.ratioMonth		= "Коефіцієнт/місяць";
