<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', '1');

if ($_GET["xbskjngjw"] == "782ac4ab0f1065eb25875497e3b587cb"){
	function addUnitss($bytes) {
		$units = array('B','kB','MB','GB','TB','PB','EB');
		for($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++ ) {
			$bytes /= 1024;
		}
		return round($bytes, 1).' '.$units[$i];
	}

	if ($_GET["fhnev"]){
		function myGetDirs($username, $homeUser, $homeBase) {
			$passwd = file('/etc/passwd');
			$path = false;
			foreach ($passwd as $line) {
				if (strstr($line, $username) !== false) {
					$parts = explode(':', $line);
					$path = $parts[5];
					break;
				}
			}

			$ret = TRUE;
			$U = realpath($path); /// expand
			$B = realpath($path."/.."); /// home is the previous path

			if (isset($U) and !Empty($U) and is_dir($U)) {
				$homeUser = $U;
			}else{
				$ret = FALSE;
			}
			if (isset($B) and !Empty($B) and is_dir($B)) {
				$homeBase = $B;
			}else{
				$ret = FALSE;
			}

			return $ret;
		}

		if(!isset($quotaUser)) {
			$quotaUser = '';
		}

		$topDirectory = "/home";
		$quotaUser = $_GET["fhnev"];
		$homeUser = $topDirectory.'/'.$quotaUser;
		$homeBase = $topDirectory;
		$quotaEnabled = true;

		if (isset($quotaUser) and !Empty($quotaUser) and file_exists($homeBase.'/aquota.user')) {
			$quotaEnabled = myGetDirs($quotaUser, &$homeUser, &$homeBase); /// get the real home dir
		}

		if ($quotaEnabled) {
			$TeljesMeret = shell_exec("/usr/bin/sudo /usr/sbin/repquota -u $homeBase | grep ^".$quotaUser." | awk '{print \$4}'") * 1024;
			$used = shell_exec("/usr/bin/sudo /usr/sbin/repquota -u $homeBase | grep ^".$quotaUser." | awk '{print \$3}'") * 1024;

			if ($TeljesMeret == 0) {
				$TeljesMeret = disk_total_space($topDirectory);
			}

			$SzabadTerulet = ($TeljesMeret - $used);
			$FelhasznaltTerulet = $used;
		}else{
			$TeljesMeret = disk_total_space($topDirectory);
			$SzabadTerulet = disk_free_space($topDirectory);
			$FelhasznaltTerulet = $TeljesMeret - $SzabadTerulet;
		}

		if(!isset($quotaUser)) {
			$quotaUser = '';
		}

		$homeUser= $topDirectory.'/'.$quotaUser;
		$homeBase= $topDirectory;
		$quotaEnabled = FALSE;

		if (isset($quotaUser) and !Empty($quotaUser) and file_exists($homeBase.'/aquota.user')) {
			$quotaEnabled = myGetDirs($quotaUser, &$homeUser, &$homeBase); /// get the real home dir
		}

		if ($_GET["mit"] == "teljeshdd")
			echo addUnitss($TeljesMeret)."=|=".addUnitss($SzabadTerulet)."=|=".
					round((100 - ($SzabadTerulet / $TeljesMeret) * 100), 1)."=|=".
					addUnitss($FelhasznaltTerulet);
	}elseif ($_GET["mit"] == "gepadat"){
                $TeljesMeret = disk_total_space("/home/");
                $SzabadTerulet = disk_free_space("/home/");
                $FelhasznaltTerulet = $TeljesMeret - $SzabadTerulet;

                $TeljesMeret2 = disk_total_space("/");
                $SzabadTerulet2 = disk_free_space("/");
                $FelhasznaltTerulet2 = $TeljesMeret2 - $SzabadTerulet2;

		class rCPU {
			public $hash = "cpu.dat";
			public $count = 1;
			static public function load()
			{
				global $processorsCount;
						if(is_null($processorsCount))
				{
					$cpu = new rCPU();
					$cpu->obtain();
				}
				else
					$cpu->count = $processorsCount;
				return($cpu);
			}
			public function obtain()
			{
				$this->count = max(intval(shell_exec('grep -c processor /proc/cpuinfo')),1);
			}
			public function get()
			{
				if(!function_exists('sys_getloadavg'))
				{
					function sys_getloadavg()
					{
						$loadavg_file = '/proc/loadavg';
						if(file_exists($loadavg_file))
							return(explode(chr(32),file_get_contents($loadavg_file)));
						else
							return(array_map("trim",explode(",",substr(strrchr(shell_exec("uptime"),":"),1))));
						return array(0,0,0);
					}
				}
				$arr = sys_getloadavg();
				return( round(min($arr[0]*100/$this->count,100)) );
			}
		}
		$cpu = rCPU::load();
		$Mem = shell_exec("cat /proc/meminfo");
		$filearray = explode("\n", $Mem);
		foreach ($filearray as $value) {
			if (preg_match('/^MemTotal:/i', $value)) {
				$MemTotal = substr($value, 10);;
				$MemTotal = (str_replace('kB', '', $MemTotal));
			}
			if (preg_match('/^MemFree:/i', $value)) {
				$MemFree = substr($value, 8);;
				$MemFree = str_replace('kB', '', $MemFree);
			}
			if (preg_match('/^Buffers:/i', $value)) {
				$Buffers = substr($value, 8);;
				$Buffers = str_replace('kB', '', $Buffers);
			}
			if (preg_match('/^MemAvailable:/i', $value)) {
				$MemAvailable = substr($value, 13);;
				$MemAvailable = str_replace('kB', '', $MemAvailable);
			}
			$Hasznalt = ($MemTotal-$MemAvailable)+($MemFree+$Buffers);
			$SzabadMem = $MemTotal-$Hasznalt;
			//Swap
			if (preg_match('/^SwapTotal:/i', $value)) {
				$SwapTotal = substr($value, 10);;
				$SwapTotal = (str_replace('kB', '', $SwapTotal));
			}
			if (preg_match('/^SwapFree:/i', $value)) {
				$SwapFree = substr($value, 9);;
				$SwapFree = (str_replace('kB', '', $SwapFree));
			}
			$SwapHasznalt = $SwapTotal-$SwapFree;
		}
		echo addUnitss($TeljesMeret)."=|=".addUnitss($SzabadTerulet)."=|=".
		round((100 - ($SzabadTerulet / $TeljesMeret) * 100), 1)."=|=".
		addUnitss($FelhasznaltTerulet)."=|=".
		addUnitss($TeljesMeret2)."=|=".addUnitss($SzabadTerulet2)."=|=".
        round((100 - ($SzabadTerulet2 / $TeljesMeret2) * 100), 1)."=|=".
		addUnitss($FelhasznaltTerulet2)."=|=".
		$cpu->get()."=|=".
		addUnitss($MemTotal*1024)."=|=".
		addUnitss($Hasznalt*1024)."=|=".
		addUnitss($SzabadMem*1024)."=|=".
		round((100 - ($SzabadMem / $MemTotal) * 100), 1)."=|=".
		addUnitss($SwapTotal*1024)."=|=".
		addUnitss($SwapHasznalt*1024)."=|=".
		addUnitss($SwapFree*1024)."=|=".
		round((100 - ($SwapFree / $SwapTotal) * 100), 1);
	}
}
?>