﻿/*
 * PLUGIN CREATE
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.mnu_create			= "Créer un torrent...";
 theUILang.CreateNewTorrent		= "Créer un nouveau Torrent";
 theUILang.SelectSource 		= "Sélectionner la source";
 theUILang.TorrentProperties		= "Propriétés du torrent";
 theUILang.PieceSize			= "Taille des pièces";
 theUILang.Other			= "Autre";
 theUILang.StartSeeding 		= "Mettre en seed";
 theUILang.PrivateTorrent		= "Tracker privé";
 theUILang.torrentCreate		= "Créer...";
 theUILang.BadTorrentData		= "Vous devez remplir tous les champs requis";
 theUILang.createExternalNotFound	= "Plug-in 'Create' : Le serveur Web n'a pas accès au programme externe. Le plug-in ne fonctionnera pas.";
 theUILang.incorrectDirectory		= "Mauvais répertoire";
 theUILang.cantExecExternal		= "Ne peut pas exécuter le programme externe";
 theUILang.createConsole		= "Console";
 theUILang.createErrors 		= "Erreurs";
 theUILang.torrentSave			= "Enregistrer";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Le processus a été interrompu.";

thePlugins.get("create").langLoaded();