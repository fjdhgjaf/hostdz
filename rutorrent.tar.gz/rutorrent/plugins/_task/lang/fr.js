﻿/*
 * PLUGIN _TASK
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.tskCommand		= "Commande en cours...";
 theUILang.tskCommandDone	= "Commande terminée.";
 theUILang.tskConsole		= "Console";
 theUILang.tskErrors		= "Diagnostiques";

thePlugins.get("_task").langLoaded();