﻿/*
 * PLUGIN _TASK
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Выполнение команды...";
 theUILang.tskCommandDone	= "Команда выполнена.";
 theUILang.tskConsole		= "Консоль";
 theUILang.tskErrors		= "Диагностика";

thePlugins.get("_task").langLoaded();