﻿/*
 * PLUGIN _TASK
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.tskCommand		= "Λειτουργεί...";
 theUILang.tskCommandDone	= "Τελείωσε.";
 theUILang.tskConsole		= "Κονσόλα";
 theUILang.tskErrors		= "Διαγνωστικά";

thePlugins.get("_task").langLoaded();