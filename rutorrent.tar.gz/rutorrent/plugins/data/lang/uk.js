﻿/*
 * PLUGIN DATA
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.getData		= "Отримати файл";
 theUILang.cantAccessData	= "Користувач веб-сервера не має доступу до даних цього торента.";

thePlugins.get("data").langLoaded();