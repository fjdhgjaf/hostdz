﻿/*
 * PLUGIN DATADIR
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.DataDir		= "Зберегти до";
 theUILang.DataDirMove		= "Перемістити файли даних";
 theUILang.datadirDlgCaption	= "Настройка каталогу даних";
 theUILang.datadirDirNotFound	= "Плагін DataDir: неприпустимий каталог";
 theUILang.datadirSetDirFail	= "Плагін DataDir: операцію не виконано";
 theUILang.datadirPHPNotFound	= "Плагін DataDir: користувачу rTorrent недоступний інтерпретатор PHP. Плагін не працюватиме.";

thePlugins.get("datadir").langLoaded();